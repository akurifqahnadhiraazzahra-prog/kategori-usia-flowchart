# Konverter Kode Program ke Flowchart

Website statis bertema Candy & Coquette untuk visualisasi flowchart kategori usia pasien.

## Menjalankan di HP atau komputer
1. Ekstrak file ZIP.
2. Buka `index.html` di browser (Chrome, Edge, Firefox, dll).

## Mempublikasikan agar bisa diakses publik

### Pilihan A — GitHub Pages (gratis)
1. Masuk atau daftar di https://github.com
2. Buat repository baru, misalnya `kategori-usia-flowchart`.
3. Unggah file `index.html` ke bagian utama (root) repository.
4. Buka **Settings → Pages**.
5. Pada **Build and deployment**, pilih **Deploy from a branch**.
6. Pilih branch `main` dan folder `/(root)`, lalu tekan **Save**.
7. Tunggu proses publikasi selesai. GitHub akan menampilkan alamat website publik di halaman Pages.

### Pilihan B — Netlify Drop (praktis)
1. Ekstrak ZIP ini sehingga terlihat file `index.html`.
2. Buka https://app.netlify.com/drop
3. Seret folder proyek yang berisi `index.html` ke halaman tersebut.
4. Netlify akan menerbitkan situs dan memberikan URL publik.

## Catatan
- Situs ini tidak memerlukan server atau database.
- Tombol unduh menghasilkan file SVG.
- Generator dibuat untuk pola program kategori usia contoh; ia bukan penerjemah universal untuk semua kode Python.
